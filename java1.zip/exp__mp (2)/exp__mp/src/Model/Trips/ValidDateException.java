package Model.Trips;

public class ValidDateException extends Exception{
    public ValidDateException(String message){
        super(message);
    }
}
